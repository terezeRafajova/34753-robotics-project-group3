"""One-time calibration for a changed camera mount. See README for the CSV columns."""
import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np

from kinematics import fk
from arm import check_angles


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("points", type=Path)
    parser.add_argument("--joints", type=float, nargs=4, required=True)
    parser.add_argument("--output", type=Path, default=Path("setup-new.json"))
    args = parser.parse_args()
    joints = np.array(args.joints)
    check_angles(joints)
    with args.points.open(newline="") as f:
        rows = list(csv.DictReader(f))
    keys = [r["key"].strip().upper() for r in rows]
    if len(set(keys)) != len(keys) or len(rows) < 6 or any(k not in set("QWERTYUIOPASDFGHJKLZXCVBNM") for k in keys):
        parser.error("Supply at least six distinct letter keys across rows and columns.")
    if len({i for i, row in enumerate(("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"))
            if any(k in row for k in keys)}) < 2:
        parser.error("Spread the measurements across rows.")
    values = np.array([[float(r[c]) for c in ("u", "v", "x", "y", "z")] for r in rows])
    if not np.isfinite(values).all():
        parser.error("Every observation must be finite.")
    pixels, xy, heights = values[:, :2], values[:, 2:4], values[:, 4]
    if np.any(pixels < 0) or np.any(pixels >= [640, 480]):
        parser.error("Use pixel coordinates from the 640 by 480 reference photo.")
    # Leave one point out at a time to catch swapped coordinates or a poor spread.
    for i in range(len(rows)):
        use = np.arange(len(rows)) != i
        h, _ = cv2.findHomography(pixels[use], xy[use])
        if h is None or np.linalg.norm(cv2.perspectiveTransform(pixels[None, i:i+1], h)[0, 0] - xy[i]) > 4:
            parser.error(f"Independent check failed at {keys[i]}. Recheck the point correspondences.")
    base_to_image, _ = cv2.findHomography(xy, pixels, 0)
    z = float(max(heights))
    camera = fk(joints)[1]
    rays = camera[:3, :3].T @ np.column_stack(([1, 0, 0], [0, 1, 0], [0, 0, z] - camera[:3, 3]))
    setup = json.loads(Path(__file__).with_name("setup.json").read_text())
    setup.update(home=joints.tolist(), surface_z=z, surface_samples=dict(zip(keys, heights.tolist())),
                 views=[dict(joints=joints.tolist(), projection=(base_to_image @ np.linalg.inv(rays)).tolist())])
    with args.output.open("x") as f:
        json.dump(setup, f, indent=2)
    print(f"Saved {args.output}. Check the setup measurements before installing it as setup.json.")


if __name__ == "__main__":
    main()
